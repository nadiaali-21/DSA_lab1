/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package doublylinkedlist;

/**
 *
 * @author ESHOP
 */
public class Doublylinkedlist {

    public class Node{
        int data;
        Node next;
        Node previous;
       Node(int data){
           this.data=data;
           this.next=null;
           this.previous=null;       
       } 
    }
    private Node head;
    private Node tail;
      
      Doublylinkedlist(){
          this.head=null; 
          this.tail=null;
      }
      
    public void addAtStart(int Data){
        Node newNode=new Node(Data);
        if(head==null){
            head=tail=newNode;
        }else{
            newNode.next=head;
            head.previous=newNode;
            head=newNode;
        }
    }
    public void addAtend(int data){
        Node newNode=new Node(data);
        if(head==null){
            head=tail=newNode;
        }
        else{
            tail.next = newNode;
            newNode.previous = tail;
            tail = newNode;

        }
    }
    public void addAtmiddle(int data, int pos){
        Node newNode= new Node(data);
         Node current=head;
            for(int i=0; i<pos-1; i++){
                current=current.next;         
        }
            newNode.next=current.next;
            newNode.previous=current.previous;
            current.next=newNode;
                    
    }
    public void deleteFromStart() {
        if (head == null) {
            System.out.println("List is empty.");
        } else {
            head = head.next;
            if (head != null) {
                head.previous = null;
            }
        }
    }

    // Method to delete the last node
    public void deleteFromEnd() {
        if (head == null) {
            System.out.println("List is empty.");
        } else if (head.next == null) {
            head = null;
        } else {
            Node temp = head;
            while (temp.next != null) {
                temp = temp.next;
            }
            temp.previous.next = null;
        }
    }

    // Method to delete a node by value
    public void deleteByValue(int data) {
        if (head == null) {
            System.out.println("List is empty.");
            return;
        }

        if (head.data == data) {
            deleteFromStart();
            return;
        }

        Node temp = head;
        while (temp != null && temp.data != data) {
            temp = temp.next;
        }

        if (temp == null) {
            System.out.println("Value not found in the list.");
        } else {
            if (temp.next != null) {
                temp.next.previous = temp.previous;
            }
            temp.previous.next = temp.next;
        }
    }

    // Method to display the list from start to end
    public void displayFromStart() {
        if (head == null) {
            System.out.println("List is empty.");
            return;
        }

        Node temp = head;
        while (temp != null) {
            System.out.print(temp.data + " <-> ");
            temp = temp.next;
        }
        System.out.println("null");
    }

    // Method to display the list from end to start
    public void displayFromEnd() {
        if (head == null) {
            System.out.println("List is empty.");
            return;
        }

        Node temp = head;
        while (temp.next != null) {
            temp = temp.next;
        }

        while (temp != null) {
            System.out.print(temp.data + " <-> ");
            temp = temp.previous;
        }
        System.out.println("null");
    }

    // Method to search for a value in the list
    public void search(int value) {
        Node current = head;
        int position = 0;

        while (current != null) {
            if (current.data == value) {
                System.out.println("Value " + value + " found at position " + position);
                return;
            }
            current= current.next;
            position++;
        }

        System.out.println("Value " + value + " not found.");
    }

    public void reverse() {
        Node current = head;
        Node prev = null;

        while (current != null) {
            prev = current.previous;
            current.previous = current.next;
            current.next = prev;
            current = current.previous;
        }

        if (prev != null) {
            head = prev.previous;
        }
    }

   
    public int countNodes() {
        Node temp = head;
        int count = 0;

        while (temp != null) {
            count++;
            temp = temp.next;
        }

        return count;
    }

    public static void main(String[] args) {
        // TODO code application logic here
        Doublylinkedlist list=new Doublylinkedlist();
        list.addAtStart(20);
        list.addAtend(30);
        list.addAtend(50);
        list.addAtend(60);
        list.addAtmiddle(40, 2);
        list.reverse();
        list.deleteFromStart();
        list.displayFromStart();
        list.deleteFromEnd();
        list.displayFromEnd();
        list.deleteByValue(50);
        list.displayFromStart();
        list.search(30);
        
      
        
    }
    
}
