
package exercise01;

public class Exercise01 {
   
    public static void main(String[] args) {
        // TODO code application logic here
         System.out.println("Task 01");
         System.out.println("All the elements present in ray: array: ");
         int arr[]={5,15,25,35,45};
         for(int i=0;i<arr.length;i++){
             System.out.println(arr[i]);
    }
         System.out.println("Task 02");
         for(int i=0;i<arr.length;i++){
             System.out.println("Element at index "+ i +": "+arr[i]);
    }
    }  
}
