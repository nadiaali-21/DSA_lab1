/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package palindrome;

/**
 *
 * @author Ali.1749913
 */
import java.util.Scanner;
public class Palindrome {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner scan=new Scanner(System.in);
        String word=scan.next();
        int left=0;
        int right=word.length()-1;
        boolean palindrome=true;
        while(left<=right){
            if(word.charAt(left)!=word.charAt(right)){
                palindrome=false;
                break;
            }
            else{
                left++;
                right--;
            }
        }
        if(palindrome==true){
            System.out.println("Its a palindrome word.");
        }
        else{
            System.out.println("Not a palindrome");
        }
    }
    
}
