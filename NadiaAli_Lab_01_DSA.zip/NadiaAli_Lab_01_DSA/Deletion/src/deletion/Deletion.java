package deletion;

public class Deletion {
    public static void main(String[] args) {
        // TODO code application logic here
        int arr[]={8,16,24,32,40};
        int dltindx=2;
        for(int i=dltindx;i<arr.length-1;i++){
             arr[i]=arr[i+1];
         }
             arr[arr.length-1] =0;
             System.out.println("After deletion: ");
             for(int i=0; i<arr.length;i++){
                 System.out.println(arr[i]);
             }
                   
    }
    
}
