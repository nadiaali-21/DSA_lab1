/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package linearsearching;

/**
 *
 * @author Ali.1749913
 */
public class LinearSearching {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        System.out.println("Linear Searching");
        int arr[]={4,6,8,10};
        int element=8;
        for(int i=0; i<arr.length;i++){
            if(arr[i]==element){
            System.out.println(element+" found at index: "+i);
        }
        }        
    }
    
}
