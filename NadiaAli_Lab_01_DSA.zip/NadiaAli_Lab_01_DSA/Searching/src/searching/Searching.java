
package searching;

public class Searching {

    public static void main(String[] args) {
        // TODO code application logic here
        System.out.println("Searching by index: ");
        int arr[]={13,26,39,52,65};
        int indx=4;
        System.out.println("Element at index");
        System.out.println(indx+": "+arr[indx]);
    }
    
}
