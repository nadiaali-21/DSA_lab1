/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package binarysearching;

/**
 *
 * @author Ali.1749913
 */
public class BinarySearching {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int arr[]={11,22,33,44,55};
        int target=33;
        int l=0;
        int R=arr.length-1;
        while(l<=R){
            int mid=l+(R-l)/2;
        if(arr[mid]==target){
            System.out.println("Element fount at "+mid+" index");
            break;
            
        }
        else if(arr[mid]<target){
            l=mid+1;
        }
        else{
            R=mid-1;
        }
        }
        
    }
    
}
