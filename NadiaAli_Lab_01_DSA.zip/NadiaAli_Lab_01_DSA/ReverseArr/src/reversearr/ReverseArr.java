

package reversearr;
import java.util.Scanner;
public class ReverseArr {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner scan=new Scanner(System.in);
        
        int arr[]=new int[5];
        for(int i=0;i<arr.length;i++){
            arr[i]=scan.nextInt();
        }
        int arr1[]=new int[5];
        for(int i=arr.length-1,j=0;i>=0;i--,j++){
            arr1[j]=arr[i];
        }
        for(int i=0;i<arr1.length;i++){
            System.out.println(arr1[i]+" ");
        }
    }
    
}
